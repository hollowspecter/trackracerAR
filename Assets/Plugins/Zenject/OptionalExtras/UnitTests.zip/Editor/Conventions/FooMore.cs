#if !(UNITY_WSA && ENABLE_DOTNET)

namespace Zenject.Tests.Convention.NamespaceTest
{
    public class Bar
    {
    }

    public class Foo4 : IFoo
    {
    }
}

#endif
